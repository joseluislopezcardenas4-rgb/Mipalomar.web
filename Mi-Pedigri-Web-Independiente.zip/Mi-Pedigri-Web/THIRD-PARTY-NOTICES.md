# Recursos y dependencias

La licencia MIT del proyecto no reemplaza las licencias de las bibliotecas y recursos de terceros. Los paquetes instalados incluyen sus propias licencias. Se conservan las notificaciones de la hoja de estilos shadcn en `vendor/` y de la fuente en `public/fonts/next-license.md`. Las imágenes del logotipo proceden del proyecto original Mi Pedigrí.

React, Vite, Radix UI, Tailwind, next-themes, sonner y las demás dependencias conservan las licencias incluidas en sus distribuciones. Los iconos Lucide se distribuyen bajo ISC. No se incluye el código de las bibliotecas en el archivo fuente salvo los componentes y recursos con sus correspondientes notificaciones. La compilación en `dist/` incluye las bibliotecas necesarias para ejecutar la aplicación.
