import {readdir,writeFile,readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
const folder=resolve('dist');
async function files(dir,prefix=''){const entries=await readdir(dir,{withFileTypes:true});const out=[];for(const e of entries){const path=prefix+'/'+e.name;if(e.isDirectory())out.push(...await files(resolve(dir,e.name),path));else if(e.name!=='sw.js')out.push(path);}return out;}
const paths=await files(folder);const version=createHash('sha256').update(await readFile(resolve(folder,'index.html'))).digest('hex').slice(0,12);
await writeFile(resolve(folder,'sw.js'),`
const STATIC='pedigri-static-${version}',PHOTOS='pedigri-photos-v1',FILES=${JSON.stringify(paths)};
self.addEventListener('install',event=>{event.waitUntil(caches.open(STATIC).then(cache=>cache.addAll(FILES)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('pedigri-static-')&&k!==STATIC).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{const request=event.request,url=new URL(request.url);if(request.method!=='GET'||url.origin!==self.location.origin)return;
if(url.pathname.startsWith('/api/photos/')){event.respondWith((async()=>{try{const response=await fetch(request);if(response.ok){const cache=await caches.open(PHOTOS);await cache.put(request,response.clone());const keys=await cache.keys();if(keys.length>120)await cache.delete(keys[0]);}return response;}catch{const cached=await caches.match(request);return cached||new Response(null,{status:503});}})());return;}
if(url.pathname.startsWith('/api/'))return;
if(request.mode==='navigate'){event.respondWith((async()=>{try{return await fetch(request);}catch{return (await caches.open(STATIC)).match('/index.html');}})());return;}
event.respondWith(caches.open(STATIC).then(async cache=>{const stored=await cache.match(url.pathname);return stored||fetch(request);}));
});
`);
console.log('Modo sin conexión preparado.');
