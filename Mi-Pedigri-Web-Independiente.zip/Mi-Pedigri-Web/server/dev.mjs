import {spawn} from 'node:child_process';
const children=[spawn(process.execPath,['server/index.mjs'],{stdio:'inherit',env:{...process.env,PUBLIC_URL:'http://localhost:5173'}}),spawn(process.execPath,['node_modules/vite/bin/vite.js'],{stdio:'inherit'})];
function stop(){for(const c of children)c.kill();}
for(const sig of ['SIGINT','SIGTERM'])process.on(sig,stop);
for(const c of children)c.on('exit',code=>{stop();process.exitCode=code||0;});
