import http from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {randomBytes,randomUUID,scrypt,timingSafeEqual,createHash} from 'node:crypto';
import {promisify} from 'node:util';
import {mkdir,readFile,writeFile,unlink,stat} from 'node:fs/promises';
import {resolve,dirname,extname,sep} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const derive=promisify(scrypt),root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const hash=v=>createHash('sha256').update(v).digest('hex');
const fault=(status,message)=>Object.assign(new Error(message),{status});
const normalize=v=>{v=String(v||'').trim();return v.includes('@')?v.toLowerCase():v.replace(/\D/g,'');};
const isContact=v=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)||/^\+?\d{8,15}$/.test(v);
const phone=v=>String(v||'').replace(/\D/g,'');
const TYPES={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.webmanifest':'application/manifest+json','.woff2':'font/woff2','.jpg':'image/jpeg','.webp':'image/webp','.json':'application/json'};
export async function createApp({dataDir=resolve(process.env.DATA_DIR||resolve(root,'data')),publicUrl=process.env.PUBLIC_URL||'http://localhost:3000',staticDir=resolve(root,'dist')}={}){
 await mkdir(resolve(dataDir,'photos'),{recursive:true});const db=new DatabaseSync(resolve(dataDir,'pedigri.sqlite'));db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;');db.exec(await readFile(resolve(root,'server/schema.sql'),'utf8'));
 const origin=new URL(publicUrl).origin,secure=origin.startsWith('https:'),limits=new Map();
 if(process.env.NODE_ENV==='production'&&!secure)throw Error('PUBLIC_URL debe utilizar HTTPS en producción.');
 function rate(key,max,interval){const now=Date.now();let x=limits.get(key);if(!x||now>x.until){x={count:0,until:now+interval};limits.set(key,x);}if(++x.count>max)throw fault(429,'Demasiados intentos. Espera unos minutos.');if(limits.size>10000)for(const [k,v] of limits)if(now>v.until)limits.delete(k);}
 function user(req){const match=(req.headers.cookie||'').match(/(?:^|;\s*)pedigri_session=([a-f0-9]{64})(?:;|$)/);if(!match)return null;return db.prepare('SELECT users.id,users.contact,users.name,users.whatsapp FROM users JOIN sessions ON sessions.user_id=users.id WHERE sessions.token=? AND sessions.expires>?').get(hash(match[1]),Date.now())||null;}
 function required(req){const u=user(req);if(!u)throw fault(401,'Inicia sesión para continuar.');return u;}
 function cookie(token,age=604800){return `pedigri_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${secure?'; Secure':''}`;}
 function send(res,status,data,extra={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...extra});res.end(JSON.stringify(data));}
 async function body(req,max=6_000_000){let size=0;const chunks=[];for await(const c of req){size+=c.length;if(size>max)throw fault(413,'El archivo o formulario es demasiado grande.');chunks.push(c);}return Buffer.concat(chunks);}
 async function json(req){try{return JSON.parse((await body(req,32000)).toString());}catch(e){if(e.status)throw e;throw fault(400,'Formulario no válido.');}}
 async function session(res,id){const token=randomBytes(32).toString('hex');db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());db.prepare('INSERT INTO sessions(token,user_id,expires) VALUES (?,?,?)').run(hash(token),id,Date.now()+604800000);send(res,200,{ok:true},{'Set-Cookie':cookie(token)});}
 function profile(u){return u?{user:{id:u.id,name:u.name,email:u.contact},profile:u.name&&u.whatsapp?{name:u.name,contact:u.contact,whatsapp:u.whatsapp}:null}:{user:null,profile:null};}
 const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; font-src 'self'; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
  try{const url=new URL(req.url,origin),path=url.pathname,method=req.method;
   if(path.startsWith('/api/')&&method!=='GET'&&method!=='HEAD'){if(req.headers.origin!==origin)throw fault(403,'Solicitud no válida. Recarga la página.');rate('write:'+req.socket.remoteAddress,150,60000);}
   if(path==='/api/auth/register'&&method==='POST'){
    rate('auth:'+req.socket.remoteAddress,15,900000);const p=await json(req),contact=normalize(p.contact);
    if(!isContact(contact)||contact.length>150||typeof p.password!=='string'||p.password.length<10||p.password.length>256||typeof p.name!=='string'||!p.name.trim()||p.name.length>100||!/^\d{8,15}$/.test(phone(p.whatsapp))||p.accepted!==true)throw fault(400,'Completa los campos, utiliza una contraseña de al menos 10 caracteres y acepta los términos.');
    const salt=randomBytes(16).toString('hex'),password=(await derive(p.password,salt,64)).toString('hex'),id=randomUUID();
    try{db.prepare('INSERT INTO users (id,contact,name,whatsapp,password,salt,accepted) VALUES (?,?,?,?,?,?,?)').run(id,contact,p.name.trim(),phone(p.whatsapp),password,salt,new Date().toISOString());}catch(e){if(String(e).includes('UNIQUE'))throw fault(409,'Ya existe una cuenta con ese correo o teléfono.');throw e;}
    return await session(res,id);
   }
   if(path==='/api/auth/login'&&method==='POST'){
    rate('auth:'+req.socket.remoteAddress,15,900000);const p=await json(req);if(typeof p.password!=='string'||p.password.length>256)throw fault(400,'Revisa tus datos de acceso.');const contact=normalize(p.contact);rate('contact:'+contact,15,900000);const u=db.prepare('SELECT * FROM users WHERE contact=?').get(contact),derived=await derive(p.password,u?.salt||'missing-account-salt',64);if(!u||!timingSafeEqual(derived,Buffer.from(u.password,'hex')))throw fault(401,'Correo, teléfono o contraseña incorrectos.');return await session(res,u.id);
   }
   if(path==='/api/auth/logout'&&method==='POST'){const c=(req.headers.cookie||'').match(/pedigri_session=([a-f0-9]{64})/);if(c)db.prepare('DELETE FROM sessions WHERE token=?').run(hash(c[1]));return send(res,200,{ok:true},{'Set-Cookie':cookie('',0)});}
   if(path==='/api/profile'&&method==='GET')return send(res,200,profile(user(req)));
   if(path==='/api/profile'&&method==='POST'){const u=required(req),p=await json(req);if(typeof p.name!=='string'||!p.name.trim()||p.name.length>100||typeof p.contact!=='string'||normalize(p.contact)!==u.contact||!/^\d{8,15}$/.test(phone(p.whatsapp))||p.accepted!==true)throw fault(400,'Revisa el nombre y WhatsApp. El identificador de acceso no puede modificarse aquí.');db.prepare('UPDATE users SET name=?,whatsapp=? WHERE id=?').run(p.name.trim(),phone(p.whatsapp),u.id);return send(res,200,{ok:true});}
   if(path==='/api/market'&&method==='GET')return send(res,200,{listings:db.prepare('SELECT id,title,category,price,currency,description,whatsapp,photo,seller,created FROM listings ORDER BY created DESC LIMIT 200').all()});
   if(path==='/api/market'&&method==='POST'){
    const u=required(req);rate('post:'+u.id,30,3600000);const bytes=await body(req);let f;try{f=await new Request(origin+path,{method:'POST',headers:{'Content-Type':req.headers['content-type']||''},body:bytes}).formData();}catch{throw fault(400,'Formulario no válido.');}
    const s=k=>String(f.get(k)||'').trim(),photo=f.get('photo');if(!s('title')||s('title').length>120||!['aves','salud','accesorios'].includes(s('category'))||!s('price')||!Number.isFinite(Number(s('price')))||Number(s('price'))<0||Number(s('price'))>1e9||!['USD','CUP'].includes(s('currency'))||!s('description')||s('description').length>4000||!/^\d{8,15}$/.test(phone(s('whatsapp')))||s('accepted')!=='true'||!(photo instanceof File)||!photo.size||photo.size>5_000_000||!['image/jpeg','image/png','image/webp'].includes(photo.type))throw fault(400,'Revisa los campos y utiliza una foto JPG, PNG o WebP de hasta 5 MB.');
    const image=new Uint8Array(await photo.arrayBuffer());const valid=photo.type==='image/jpeg'?image[0]===255&&image[1]===216&&image[2]===255:photo.type==='image/png'?image[0]===137&&image[1]===80&&image[2]===78&&image[3]===71:String.fromCharCode(...image.slice(0,4))==='RIFF'&&String.fromCharCode(...image.slice(8,12))==='WEBP';if(!valid)throw fault(400,'El archivo no es una imagen válida.');
    const key=req.headers['idempotency-key'];if(key&&!/^[a-f0-9-]{36}$/.test(key))throw fault(400,'Solicitud no válida.');if(key){const old=db.prepare('SELECT id FROM listings WHERE owner=? AND request_key=?').get(u.id,key);if(old)return send(res,200,{id:old.id});}
    const id=randomUUID(),filepath=resolve(dataDir,'photos',id);await writeFile(filepath,image,{flag:'wx'});try{db.prepare('INSERT INTO listings (id,owner,title,category,price,currency,description,whatsapp,photo,seller,created,mime,request_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,u.id,s('title'),s('category'),s('price'),s('currency'),s('description'),phone(s('whatsapp')),'/api/photos/'+id,u.name,new Date().toISOString(),photo.type,key||null);}catch(e){await unlink(filepath);throw e;}return send(res,201,{id});
   }
   if(path.startsWith('/api/photos/')&&method==='GET'){const id=path.slice(12);if(!/^[a-f0-9-]{36}$/.test(id))throw fault(404,'Foto no encontrada.');const row=db.prepare('SELECT mime FROM listings WHERE id=?').get(id);if(!row)throw fault(404,'Foto no encontrada.');const b=await readFile(resolve(dataDir,'photos',id));res.writeHead(200,{'Content-Type':row.mime,'Cache-Control':'public,max-age=86400'});return res.end(b);}
   if(path==='/api/records'&&method==='GET'){const u=required(req);return send(res,200,{records:db.prepare('SELECT id,kind,data,updated FROM records WHERE owner=? ORDER BY updated DESC').all(u.id).map(r=>({...r,data:JSON.parse(r.data)}))});}
   if(path==='/api/records'&&method==='POST'){
    const u=required(req),p=await json(req),requiredFields={birds:['name','ring','sex'],flights:['bird','date','minutes'],captures:['bird','date','quantity'],care:['bird','name','date','status'],breeding:['father','mother','date'],achievements:['name','date'],lofts:['name']};
    if(!requiredFields[p.kind]||!p.data||typeof p.data!=='object'||Array.isArray(p.data)||Object.keys(p.data).length>30||!Object.values(p.data).every(v=>typeof v==='string'&&v.length<=3000)||requiredFields[p.kind].some(k=>!p.data[k]?.trim()))throw fault(400,'Completa los campos del registro.');const d=p.data,id=p.id||randomUUID();if(!/^[a-f0-9-]{36}$/.test(id))throw fault(400,'Registro no válido.');
    const existing=db.prepare('SELECT owner,kind FROM records WHERE id=?').get(id);if(existing&&(existing.owner!==u.id||existing.kind!==p.kind))throw fault(403,'No puedes modificar este registro.');
    const key=req.headers['idempotency-key'];if(key){if(!/^[a-f0-9-]{36}$/.test(key))throw fault(400,'Solicitud no válida.');const replay=db.prepare('SELECT response FROM mutations WHERE owner=? AND key=?').get(u.id,key);if(replay)return send(res,200,JSON.parse(replay.response));}
    const all=db.prepare('SELECT id,kind,data FROM records WHERE owner=?').all(u.id).map(r=>({...r,data:JSON.parse(r.data)})),birds=all.filter(r=>r.kind==='birds');
    for(const key of ['minutes','quantity','distance','eggs','chicks'])if(d[key]&&(!Number.isFinite(Number(d[key]))||Number(d[key])<0))throw fault(400,'Los números deben ser positivos.');
    if(p.kind==='birds'){if(!['Macho','Hembra','Sin determinar'].includes(d.sex))throw fault(400,'Selecciona un sexo válido.');if(birds.some(b=>b.id!==id&&b.data.ring.toLowerCase()===d.ring.trim().toLowerCase()))throw fault(409,'Esta anilla ya está registrada.');const visit=(pid,seen=new Set())=>{if(pid===id)return true;if(!pid||seen.has(pid))return false;seen.add(pid);const b=birds.find(x=>x.id===pid);return b?[b.data.father,b.data.mother].some(x=>visit(x,seen)):false;};if([d.father,d.mother].filter(Boolean).some(x=>visit(x)))throw fault(400,'El parentesco no puede formar un ciclo.');}
    for(const [key,sex] of [['father','Macho'],['mother','Hembra']])if(d[key]&&!birds.some(b=>b.id===d[key]&&b.data.sex===sex))throw fault(400,'Selecciona progenitores válidos.');if(d.bird&&!birds.some(b=>b.id===d.bird))throw fault(400,'Selecciona una paloma registrada.');if(d.loft&&!all.some(r=>r.id===d.loft&&r.kind==='lofts'))throw fault(400,'Selecciona un palomar válido.');
    const result={id};db.exec('BEGIN');try{db.prepare('INSERT INTO records (id,owner,kind,data,updated) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data,updated=excluded.updated').run(id,u.id,p.kind,JSON.stringify(d),new Date().toISOString());if(key)db.prepare('INSERT INTO mutations (owner,key,response) VALUES (?,?,?)').run(u.id,key,JSON.stringify(result));db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}return send(res,200,result);
   }
   if(path==='/api/export'&&method==='GET'){const u=required(req);return send(res,200,{version:1,exported:new Date().toISOString(),records:db.prepare('SELECT id,kind,data,updated FROM records WHERE owner=?').all(u.id).map(r=>({...r,data:JSON.parse(r.data)}))},{'Content-Disposition':'attachment; filename="Mi-Pedigri-Datos.json"'});}
   if(path.startsWith('/api/'))throw fault(404,'Ruta no encontrada.');
   if(!['GET','HEAD'].includes(method))throw fault(405,'Método no permitido.');
   const decoded=decodeURIComponent(path);if(decoded.includes('\0'))throw fault(400,'Ruta no válida.');let filename=resolve(staticDir,'.'+decoded);if(filename!==staticDir&&!filename.startsWith(staticDir+sep))throw fault(403,'Ruta no válida.');try{if((await stat(filename)).isDirectory())filename=resolve(filename,'index.html');}catch{filename=resolve(staticDir,'index.html');}
   const content=await readFile(filename);res.writeHead(200,{'Content-Type':TYPES[extname(filename)]||'application/octet-stream','Cache-Control':path==='/sw.js'||extname(filename)==='.html'?'no-cache':path.startsWith('/assets/')?'public,max-age=31536000,immutable':'public,max-age=3600'});res.end(method==='HEAD'?undefined:content);
  }catch(e){if(!e.status)console.error(e);if(!res.headersSent)send(res,e.status||500,{error:e.status?e.message:'No se pudo completar la operación. Intenta nuevamente.'});else res.end();}
 });
 server.requestTimeout=30000;server.headersTimeout=15000;
 return {server,db,close:()=>new Promise(done=>server.close(()=>{db.close();done();}))};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){const app=await createApp();const port=Number(process.env.PORT||3000);app.server.listen(port,process.env.HOST||'127.0.0.1',()=>console.log(`Mi Pedigrí lista en ${process.env.PUBLIC_URL||'http://localhost:'+port}`));for(const sig of ['SIGINT','SIGTERM'])process.on(sig,()=>app.close().then(()=>process.exit(0)));}
