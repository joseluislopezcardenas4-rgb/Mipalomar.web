import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
test('service worker prepara todas las rutas, recupera la web offline y no almacena APIs privadas',async()=>{
 const handlers=new Map(),data=new Map();let connected=true;
 const key=r=>new URL(typeof r==='string'?r:r.url,'https://pedigri.test').pathname;
 const caches={keys:async()=>[...data.keys()],delete:async k=>data.delete(k),open:async name=>{if(!data.has(name))data.set(name,new Map());const map=data.get(name);return {addAll:async paths=>{for(const path of paths)map.set(path,new Response('saved '+path));},put:async(req,res)=>map.set(key(req),res),match:async req=>map.get(key(req))?.clone(),keys:async()=>[...map.keys()].map(x=>new Request('https://pedigri.test'+x)),delete:async req=>map.delete(key(req))};},match:async req=>{for(const map of data.values())if(map.has(key(req)))return map.get(key(req)).clone();}};
 const self={location:{origin:'https://pedigri.test'},clients:{claim:async()=>{}},skipWaiting:async()=>{},addEventListener:(name,fn)=>handlers.set(name,fn)};
 vm.runInNewContext(await readFile('dist/sw.js','utf8'),{self,caches,Response,URL,fetch:async()=>{if(!connected)throw Error('offline');return new Response('network');}});
 let pending;handlers.get('install')({waitUntil:p=>{pending=p;}});await pending;const staticCache=[...data.values()][0];assert.ok(staticCache.has('/index.html'));assert.ok([...staticCache.keys()].some(k=>k.includes('Palomar-')));assert.ok([...staticCache.keys()].some(k=>k.includes('Market-')));
 handlers.get('activate')({waitUntil:p=>{pending=p;}});await pending;
 connected=false;let result;handlers.get('fetch')({request:{url:'https://pedigri.test/palomar',method:'GET',mode:'navigate'},respondWith:p=>result=p});assert.match(await (await result).text(),/saved \/index.html/);
 result=undefined;handlers.get('fetch')({request:new Request('https://pedigri.test/api/profile'),respondWith:p=>result=p});assert.equal(result,undefined,'los perfiles no se guardan en Cache Storage');
 connected=true;handlers.get('fetch')({request:new Request('https://pedigri.test/api/photos/a'),respondWith:p=>result=p});assert.equal(await (await result).text(),'network');connected=false;handlers.get('fetch')({request:new Request('https://pedigri.test/api/photos/a'),respondWith:p=>result=p});assert.equal(await (await result).text(),'network');
});
