import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {createApp} from '../server/index.mjs';
test('cuentas independientes, anuncios públicos, datos privados y operaciones idempotentes',async()=>{
 const dataDir=await mkdtemp(resolve(tmpdir(),'pedigri-test-'));const app=await createApp({dataDir,publicUrl:'http://localhost:3000'});await new Promise(ok=>app.server.listen(0,'127.0.0.1',ok));const base='http://127.0.0.1:'+app.server.address().port;
 const request=async(path,{cookie='',method='GET',data,body,headers={}}={})=>fetch(base+path,{method,headers:{Origin:'http://localhost:3000',...(cookie?{Cookie:cookie}:{}),...(data?{'Content-Type':'application/json'}:{}),...headers},body:data?JSON.stringify(data):body});
 try{
 assert.equal((await request('/api/records')).status,401);
 let r=await request('/api/auth/register',{method:'POST',data:{contact:'seller@example.com',password:'correct-password-123',name:'Palomar Azul',whatsapp:'+53 51234567',accepted:true}});assert.equal(r.status,200);const seller=r.headers.get('set-cookie').split(';')[0];assert.match(r.headers.get('set-cookie'),/HttpOnly/);
 r=await request('/api/auth/register',{method:'POST',data:{contact:'+5352222222',password:'another-password-123',name:'Otro palomar',whatsapp:'+53 52222222',accepted:true}});assert.equal(r.status,200);const other=r.headers.get('set-cookie').split(';')[0];
 r=await request('/api/auth/login',{method:'POST',data:{contact:'seller@example.com',password:'wrong-password'}});assert.equal(r.status,401);
 const key=crypto.randomUUID(),id=crypto.randomUUID();const payload={id,kind:'birds',data:{name:'Campeón',ring:'CU-001',sex:'Macho'}};
 r=await request('/api/records',{method:'POST',cookie:seller,data:payload,headers:{'Idempotency-Key':key}});assert.equal(r.status,200);
 r=await request('/api/records',{method:'POST',cookie:seller,data:payload,headers:{'Idempotency-Key':key}});assert.equal(r.status,200);
 assert.equal((await (await request('/api/records',{cookie:seller})).json()).records.length,1);
 assert.equal((await (await request('/api/records',{cookie:other})).json()).records.length,0);
 assert.equal((await request('/api/records',{method:'POST',cookie:other,data:payload})).status,403);
 assert.equal((await request('/api/records',{method:'POST',cookie:seller,data:{kind:'birds',data:{name:'Otra',ring:'CU-001',sex:'Hembra'}}})).status,409);
 assert.equal((await request('/api/records',{method:'POST',cookie:seller,data:{id,kind:'birds',data:{...payload.data,father:id}}})).status,400);
 assert.equal((await fetch(base+'/api/profile',{method:'POST',headers:{Origin:'https://evil.example',Cookie:seller,'Content-Type':'application/json'},body:'{}'})).status,403);
 const form=()=>{const f=new FormData();for(const [k,v] of Object.entries({title:'Reproductor',category:'aves',price:'80',currency:'USD',description:'Reproductor de prueba',whatsapp:'5351234567',accepted:'true'}))f.set(k,v);f.set('photo',new File([Buffer.from('89504e470d0a1a0a','hex')],'photo.png',{type:'image/png'}));return f;};
 const uploadKey=crypto.randomUUID();r=await request('/api/market',{method:'POST',cookie:seller,body:form(),headers:{'Idempotency-Key':uploadKey}});assert.equal(r.status,201);const ad=await r.json();
 r=await request('/api/market',{method:'POST',cookie:seller,body:form(),headers:{'Idempotency-Key':uploadKey}});assert.equal((await r.json()).id,ad.id);
 const listings=(await (await request('/api/market')).json()).listings;assert.equal(listings.length,1);assert.equal(listings[0].seller,'Palomar Azul');assert.equal((await request(listings[0].photo)).headers.get('content-type'),'image/png');
 assert.equal((await (await request('/api/export',{cookie:seller})).json()).records.length,1);
 await request('/api/auth/logout',{method:'POST',cookie:seller});assert.equal((await request('/api/records',{cookie:seller})).status,401);
 assert.equal((await request('/palomar')).status,200);
 }finally{await app.close();await rm(dataDir,{recursive:true,force:true});}
});
