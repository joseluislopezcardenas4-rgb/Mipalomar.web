import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile,writeFile,unlink} from 'node:fs/promises';
import ts from 'typescript';
import {indexedDB} from 'fake-indexeddb';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
test('caché por cuenta, cola offline, expiración de sesión y sincronización',async()=>{
 let connected=true,who='account-a',sent=[];
 const window=new EventTarget();window.fetch=async(path,init)=>{
  if(!connected)throw new TypeError('offline');
  if(path==='/api/profile')return Response.json({user:who?{id:who,name:who,email:who+'@example.com'}:null,profile:who?{name:who,contact:who+'@example.com',whatsapp:'5351234567'}:null});
  if(path==='/api/market')return Response.json({listings:[{id:'ad-a',title:'Paloma'}]});
  if(path==='/api/records'&&init?.method==='POST'){sent.push({body:JSON.parse(init.body),key:init.headers['Idempotency-Key']});return Response.json({id:JSON.parse(init.body).id});}
  if(path==='/api/records')return Response.json({records:[]});
  throw Error('unexpected');
 };
 Object.defineProperty(globalThis,'window',{value:window,configurable:true});Object.defineProperty(globalThis,'navigator',{value:{get onLine(){return connected;}},configurable:true});globalThis.indexedDB=indexedDB;
 const filename=resolve('tests/.offline-runtime-'+process.pid+'.mjs');
 const source=await readFile('src/offline.tsx','utf8');await writeFile(filename,ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX}}).outputText);
 try{const api=await import(pathToFileURL(filename));await api.apiFetch('/api/profile');await api.apiFetch('/api/records');await api.apiFetch('/api/market');
  connected=false;assert.equal((await (await api.apiFetch('/api/market')).json()).listings.length,1);
  const save=await api.apiFetch('/api/records',{method:'POST',body:JSON.stringify({kind:'birds',data:{name:'Offline',ring:'1',sex:'Macho'}})});const saved=await save.json();assert.equal(saved.queued,true);assert.equal((await (await api.apiFetch('/api/records')).json()).records[0].id,saved.id);
  const file=new File(['photo'],'photo.jpg',{type:'image/jpeg'});await api.persist('draft:account-a',{entries:[['photo',file],['title','Borrador']]});assert.equal((await api.stored('draft:account-a')).entries[0][1].size,5);
  connected=true;who=null;await api.apiFetch('/api/profile');assert.equal((await api.stored('queue')).length,1,'una sesión caducada no pierde la cola');
  who='account-b';await api.apiFetch('/api/profile');await api.apiFetch('/api/records');connected=false;assert.equal((await (await api.apiFetch('/api/records')).json()).records.length,0,'otra cuenta no ve los datos privados');
  connected=true;await api.synchronize();assert.equal(sent.length,0,'otra cuenta no envía la cola anterior');who='account-a';await api.apiFetch('/api/profile');await api.synchronize();assert.equal(sent.length,1);assert.equal(sent[0].body.id,saved.id);assert.match(sent[0].key,/^[a-f0-9-]{36}$/);assert.equal((await api.stored('queue')).length,0);
  await api.clearPrivate();assert.equal(await api.stored('account'),undefined);assert.equal(await api.stored('draft:account-a'),undefined);assert.ok(await api.stored('public-market'));
 }finally{await unlink(filename);}
});
