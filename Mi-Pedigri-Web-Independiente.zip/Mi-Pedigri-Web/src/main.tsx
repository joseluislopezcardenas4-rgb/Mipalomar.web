import {createRoot} from 'react-dom/client';
import {lazy,Suspense,useState,useEffect} from 'react';
import Preferences from './preferences';
import {ConnectionStatus,apiFetch} from './offline';
import './globals.css';
const Market=lazy(()=>import('./Market'));const Palomar=lazy(()=>import('./Palomar'));const Terms=lazy(()=>import('./Terms'));
function PrivatePalomar(){const [state,setState]=useState('loading');useEffect(()=>{void apiFetch('/api/profile').then(r=>r.json()).then(d=>setState(d.user?'ready':'login')).catch(()=>setState('error'));},[]);if(state==='ready')return <Palomar/>;return <div className="market"><main className="market-main"><div className="market-form-panel"><h1>Mi palomar</h1><p>{state==='loading'?'Cargando tu cuenta…':state==='error'?'No se pudo cargar tu cuenta. Intenta de nuevo con conexión.':'Inicia sesión para consultar tu palomar privado. Después podrás abrirlo sin internet en este dispositivo.'}</p><a className="market-primary" href="/?view=account">Mi cuenta</a><a className="market-back" href="/">Volver al muro</a></div></main></div>;}
const App=location.pathname==='/palomar'?PrivatePalomar:location.pathname==='/terminos'?Terms:Market;
createRoot(document.getElementById('root')!).render(<Preferences><ConnectionStatus/><Suspense fallback={<p className="offline-banner">Abriendo Mi Pedigrí…</p>}><App/></Suspense></Preferences>);
if('serviceWorker' in navigator&&!import.meta.env.DEV){navigator.serviceWorker.register('/sw.js').then(()=>navigator.serviceWorker.ready).then(()=>navigator.storage?.persist?.()).catch(()=>{});}
