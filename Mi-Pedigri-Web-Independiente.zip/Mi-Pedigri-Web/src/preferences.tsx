'use client';
import {ThemeProvider,useTheme} from 'next-themes';
import {createContext,useContext,useEffect,useState,ReactNode} from 'react';
type InstallEvent=Event&{prompt:()=>Promise<void>;userChoice:Promise<{outcome:string}>};
type PreferencesState={largeText:boolean;setLargeText:(value:boolean)=>void;install:InstallEvent|null;installed:boolean;installApp:()=>Promise<void>};
const Context=createContext<PreferencesState>({largeText:false,setLargeText:()=>{},install:null,installed:false,installApp:async()=>{}});
export const usePreferences=()=>useContext(Context);
function Runtime({children}:{children:ReactNode}){const {resolvedTheme}=useTheme();useEffect(()=>{document.querySelector('meta[name="theme-color"]')?.setAttribute("content",resolvedTheme==='dark'?'#101b22':'#116b60')},[resolvedTheme]);const [largeText,setLarge]=useState(false),[install,setInstall]=useState<InstallEvent|null>(null),[installed,setInstalled]=useState(false);
useEffect(()=>{try{const value=localStorage.getItem('mi-pedigri-large-text')==='true';setLarge(value);document.documentElement.dataset.textSize=value?'large':'normal';}catch{}const mode=window.matchMedia('(display-mode: standalone)');const sync=()=>setInstalled(mode.matches||Boolean((navigator as Navigator&{standalone?:boolean}).standalone));sync();mode.addEventListener('change',sync);const onPrompt=(event:Event)=>{event.preventDefault();setInstall(event as InstallEvent)};const onInstalled=()=>{setInstalled(true);setInstall(null)};window.addEventListener('beforeinstallprompt',onPrompt);window.addEventListener('appinstalled',onInstalled);return ()=>{mode.removeEventListener('change',sync);window.removeEventListener('beforeinstallprompt',onPrompt);window.removeEventListener('appinstalled',onInstalled)};},[]);
const setLargeText=(value:boolean)=>{setLarge(value);document.documentElement.dataset.textSize=value?'large':'normal';try{localStorage.setItem('mi-pedigri-large-text',String(value));}catch{}};
async function installApp(){if(!install)return;await install.prompt();await install.userChoice;setInstall(null)}
return <Context.Provider value={{largeText,setLargeText,install,installed,installApp}}>{children}</Context.Provider>}
export default function Preferences({children}:{children:ReactNode}){return <ThemeProvider attribute="class" defaultTheme="system" enableSystem storageKey="mi-pedigri-theme" disableTransitionOnChange><Runtime>{children}</Runtime></ThemeProvider>}
