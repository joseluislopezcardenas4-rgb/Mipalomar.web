@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Primero instala Node.js 24 desde https://nodejs.org
  pause
  exit /b 1
)
node -e "process.exit(Number(process.versions.node.split('.')[0])>=24?0:1)"
if errorlevel 1 (
  echo Actualiza Node.js a la version 24 o posterior.
  pause
  exit /b 1
)
echo Mi Pedigri: manten esta ventana abierta.
echo Abre http://localhost:3000 en tu navegador cuando aparezca lista.
node server/index.mjs
pause
