# Mi Pedigrí · Web independiente

Versión 0.2.0. Aplicación web instalable (PWA) con código fuente MIT. No necesita ChatGPT, cuentas OpenAI, Cloudflare D1 ni R2. El muro se puede consultar sin una cuenta; para publicar y gestionar un palomar privado se usa correo o teléfono y contraseña.

## Probar en Windows sin compilar

1. Instala **Node.js 24 LTS** desde https://nodejs.org (solo la primera vez).
2. Descomprime este archivo en una carpeta propia.
3. Abre `INICIAR-WINDOWS.bat` con doble clic. Mantén abierta la ventana mientras uses la web.
4. Abre http://localhost:3000 en el navegador cuando la ventana indique que está lista. Crea una cuenta en «Mi cuenta».

La carpeta `dist/` ya contiene la web compilada. Esta prueba funciona en la computadora y **no crea un enlace público**. No abras `index.html` con doble clic: la aplicación necesita que el servidor esté funcionando.

## Qué funciona sin internet

Primero abre la web con conexión, inicia sesión, entra en «Mi palomar» y espera a que se descargue la aplicación. Para el móvil, utiliza un alojamiento HTTPS y añádela a la pantalla de inicio. La primera visita y las primeras descargas sí requieren conexión.

- La aplicación, configuración y términos se pueden abrir después sin conexión.
- Se puede consultar el último muro guardado (hasta 200 anuncios). Las fotos se guardan al ser descargadas, con un máximo de 120 fotos en caché; no se promete conservar fotos que nunca se abrieron o descargaron.
- El palomar consultado queda guardado en IndexedDB para la cuenta activa. Los registros nuevos y cambios hechos sin internet quedan pendientes y se envían al volver a abrir la aplicación con conexión y una sesión válida. Un error de validación deja el registro pendiente y muestra el motivo.
- Los borradores de venta, incluida la foto, se guardan en el dispositivo. **Nunca se publican automáticamente**: el usuario debe pulsar «Publicar anuncio» con conexión.
- Crear cuentas, iniciar sesión, ver novedades, publicar ventas y comunicarse por WhatsApp requieren internet.
- Si la sesión ha caducado, vuelve a iniciar sesión con la misma cuenta para sincronizar. Cerrar sesión borra los datos privados guardados en el dispositivo y se bloquea si existen registros pendientes.
- El navegador puede borrar datos por falta de espacio o al limpiar el historial. Descargar un respaldo desde «Mi cuenta» permite conservar los registros del servidor. Los datos pendientes solo están en el dispositivo hasta que se sincronizan.

No se incluye sincronización en segundo plano cuando la web está cerrada. Tampoco se resuelven automáticamente ediciones simultáneas del mismo registro en varios dispositivos: prevalece la última escritura que llega al servidor.

## Publicarla fuera de ChatGPT

Se necesita un servidor con Node.js 24, disco persistente y HTTPS. No basta un alojamiento de páginas estáticas (por ejemplo, GitHub Pages): las cuentas, anuncios, fotos y registros necesitan el servidor incluido.

Se incluye `compose.yaml` con servidor, almacenamiento y Caddy para HTTPS. En una máquina con Docker:

1. Apunta un dominio propio a la IP del servidor.
2. Abre los puertos 80 y 443.
3. Crea `.env` con `DOMAIN=tu-dominio.com`.
4. Ejecuta `docker compose up -d --build`.
5. Abre `https://tu-dominio.com`.

Este proyecto **todavía no está alojado públicamente**. Necesitas una cuenta de alojamiento o una máquina propia para crear el enlace independiente. El sitio anterior no se modifica ni se elimina al usar este paquete.

También puedes ejecutar `node server/index.mjs` detrás de un proxy HTTPS. Configura `PUBLIC_URL=https://tu-dominio.com`, `NODE_ENV=production`, `DATA_DIR=/ruta/persistente`, `HOST=127.0.0.1` y `PORT=3000`. En producción se exige un `PUBLIC_URL` HTTPS para activar cookies seguras. El proxy debe conservar el encabezado Origin y tener un límite de subida de al menos 6 MB.

## Desarrollar

```sh
npm ci
npm run dev
```

Abre http://localhost:5173. Para preparar producción:

```sh
npm run build
npm test
npm start
```

Abre http://localhost:3000. El modo offline se comprueba en la compilación de producción, no en el servidor de desarrollo.

## Datos y migración

SQLite y fotos están en `data/` por defecto. En Docker, están en un volumen persistente. No publiques esta carpeta, contraseñas, sesiones ni respaldos personales en repositorios públicos. Copia la carpeta completa con el servidor detenido para obtener un respaldo coherente. No uses un disco efímero ni ejecutes varias réplicas sobre esta misma base de datos.

Desde «Mi cuenta» puedes descargar los registros del palomar en JSON e importarlos en otra instalación. La importación es gradual: si un registro falla, se informa de cuántos se importaron; no es una operación atómica. Los perfiles del antiguo sitio no equivalen a cuentas con contraseña; debes crear una cuenta nueva. No se copian automáticamente anuncios ni imágenes del sitio anterior.

## Alcance de esta versión

- Contraseñas derivadas con scrypt y sales aleatorias; sesiones revocables con cookies HttpOnly y SameSite; cookies Secure en HTTPS.
- Validación de datos, comprobación de Origin y límites de intentos. Registros del palomar separados por usuario. Fotos validadas por tipo, tamaño y cabecera.
- No hay verificación por SMS/correo, recuperación automática de contraseña, panel de moderación, denuncias ni análisis antivirus de fotos. Los datos de contacto de una cuenta no están verificados.
- Antes de un lanzamiento oficial amplio, es necesario completar esas operaciones y las políticas de privacidad, eliminación de cuentas y moderación que correspondan al servicio. Los términos básicos no garantizan aceptación por Google o por las tiendas de aplicaciones.

## Código abierto

El código del proyecto se distribuye bajo MIT (`LICENSE`). Las dependencias y los recursos de terceros conservan sus propias licencias (`THIRD-PARTY-NOTICES.md`, `vendor/`, `public/fonts/`). Publicar el código en un repositorio público es independiente de publicar la web: este paquete contiene el código, pero no crea automáticamente un repositorio GitHub.

## Referencias técnicas

- SQLite de Node.js 24: https://nodejs.org/download/release/latest-v24.x/docs/api/sqlite.html
- Funcionamiento sin conexión de PWA: https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Offline_and_background_operation
